/// <mls shortName="organismMediaGallery" project="102023" enhancement="_blank" folder="music" />

 import { ICANTest, ICANIntegration, ICANSchema  } from './_100554_tsTestAST';
 export const integrations: ICANIntegration[] = [];
 export const tests: ICANTest[] = [];