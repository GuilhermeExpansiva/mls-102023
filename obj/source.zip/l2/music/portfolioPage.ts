/// <mls shortName="portfolioPage" project="102023" folder="music" enhancement="_100554_enhancementLit" groupName="music" />

import { CollabPageElement } from '_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
import { globalState, initState, setState } from '_100554_collabState';

@customElement('music--portfolio-page-102023')
export class PagePortfolioPage extends CollabPageElement {
    initPage() {

    }
}