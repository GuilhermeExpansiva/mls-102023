/// <mls shortName="project" project="102023" enhancement="_blank" groupName="other" />
export const projectConfig = {
    "masterFrontEnd": {
        "build": "",
        "start": "",
        "liveView": ""
    },
    "masterBackEnd": {
        "build": "",
        "start": "",
        "serverView": ""
    },
    "modules": [
        {
            "name": "music",
            "path": "music",
            "auth": "admin"
        }
    ]
};
