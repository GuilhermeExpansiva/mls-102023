/// <mls shortName="organismNav" project="102023" folder="music" enhancement="_100554_enhancementLit" groupName="music" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from '_100554_icaOrganismBase';
let organismNav = class organismNav extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`music--organism-nav-102023 .nav-container{display:flex;justify-content:space-between;align-items:center;padding:var(--space-16) var(--space-24);background-color:var(--bg-primary-color);border-bottom:1px solid var(--grey-color)}music--organism-nav-102023 .logo{font-family:var(--font-family-primary);font-size:var(--font-size-24);font-weight:var(--font-weight-bold);color:var(--text-secondary-color)}music--organism-nav-102023 .menu{display:flex;list-style:none;margin:0;padding:0}music--organism-nav-102023 .menu-item{margin-left:var(--space-24)}music--organism-nav-102023 .menu-link{color:var(--text-primary-color);text-decoration:none;font-size:var(--font-size-16);transition:color var(--transition-normal)}music--organism-nav-102023 .menu-link:hover{color:var(--text-secondary-color)}music--organism-nav-102023 .hamburger{display:none;flex-direction:column;cursor:pointer}music--organism-nav-102023 .hamburger-line{width:25px;height:3px;background-color:var(--text-primary-color);margin:3px 0;transition:var(--transition-normal)}@media (max-width:768px){music--organism-nav-102023 .menu{display:none;flex-direction:column;position:absolute;top:100%;left:0;width:100%;background-color:var(--bg-primary-color);padding:var(--space-16)}music--organism-nav-102023 .menu.open{display:flex}music--organism-nav-102023 .hamburger{display:flex}}`);
    }
    render() {
        return html `<div class="nav-container" id="music--nav-100000-1">
    <div class="logo" id="music--nav-100000-2">Professor de Música</div>
    <nav id="music--nav-100000-3">
      <ul class="menu" id="music--nav-100000-4">
        <li class="menu-item" id="music--nav-100000-5"><a href="#" class="menu-link" id="music--nav-100000-6">Home</a></li>
        <li class="menu-item" id="music--nav-100000-7"><a href="#" class="menu-link" id="music--nav-100000-8">Sobre</a></li>
        <li class="menu-item" id="music--nav-100000-9"><a href="#" class="menu-link" id="music--nav-100000-10">Portfólio</a></li>
        <li class="menu-item" id="music--nav-100000-11"><a href="#" class="menu-link" id="music--nav-100000-12">Galeria</a></li>
        <li class="menu-item" id="music--nav-100000-13"><a href="#" class="menu-link" id="music--nav-100000-14">Contato</a></li>
        <li class="menu-item" id="music--nav-100000-15"><a href="#" class="menu-link" id="music--nav-100000-16">Agendamento</a></li>
      </ul>
    </nav>
    <div class="hamburger" id="music--nav-100000-17">
      <span class="hamburger-line" id="music--nav-100000-18"></span>
      <span class="hamburger-line" id="music--nav-100000-19"></span>
      <span class="hamburger-line" id="music--nav-100000-20"></span>
    </div>
  </div>
`;
    }
};
organismNav = __decorate([
    customElement('music--organism-nav-102023')
], organismNav);
export { organismNav };
