/// <mls shortName="organismScheduleForm" project="102023" folder="music" enhancement="_100554_enhancementLit" groupName="music" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from '_100554_icaOrganismBase';
let organismScheduleForm = class organismScheduleForm extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`music--organism-schedule-form-102023{max-width:600px;margin:0 auto;background-color:var(--bg-secondary-color-lighter);padding:var(--space-32);border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.1)}music--organism-schedule-form-102023 .form-title{font-family:var(--font-family-primary);font-size:var(--font-size-24);font-weight:var(--font-weight-bold);color:var(--text-primary-color);margin-bottom:var(--space-24);text-align:center}music--organism-schedule-form-102023 .form-group{margin-bottom:var(--space-16)}music--organism-schedule-form-102023 .form-group label{display:block;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);color:var(--text-primary-color);margin-bottom:var(--space-8)}music--organism-schedule-form-102023 .form-group input,music--organism-schedule-form-102023 .form-group select{width:100%;padding:var(--space-8);font-family:var(--font-family-primary);font-size:var(--font-size-16);border:1px solid var(--grey-color);border-radius:4px;background-color:var(--bg-primary-color);color:var(--text-primary-color)}music--organism-schedule-form-102023 .form-group input:focus,music--organism-schedule-form-102023 .form-group select:focus{border-color:var(--active-color);outline:none}music--organism-schedule-form-102023 .submit-button{width:100%;padding:var(--space-16);font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-bold);color:var(--bg-primary-color);background-color:var(--active-color);border:none;border-radius:4px;cursor:pointer;transition:background-color var(--transition-normal)}music--organism-schedule-form-102023 .submit-button:hover{background-color:var(--active-color-hover)}music--organism-schedule-form-102023 .submit-button:focus{background-color:var(--active-color-focus);outline:none}@media (max-width:768px){music--organism-schedule-form-102023{padding:var(--space-16)}music--organism-schedule-form-102023 .form-title{font-size:var(--font-size-20)}}`);
    }
    render() {
        return html `<h2 class="form-title" id="music--schedule-form-100000-1">Agende sua Aula de Música</h2>
  <form action="/submit-schedule" method="post" id="music--schedule-form-100000-2">
    <div class="form-group" id="music--schedule-form-100000-3">
      <label for="name" id="music--schedule-form-100000-4">Nome Completo</label>
      <input type="text" id="name" name="name" required="">
    </div>
    <div class="form-group" id="music--schedule-form-100000-5">
      <label for="email" id="music--schedule-form-100000-6">E-mail</label>
      <input type="email" id="email" name="email" required="">
    </div>
    <div class="form-group" id="music--schedule-form-100000-7">
      <label for="phone" id="music--schedule-form-100000-8">Telefone</label>
      <input type="tel" id="phone" name="phone" required="">
    </div>
    <div class="form-group" id="music--schedule-form-100000-9">
      <label for="instrument" id="music--schedule-form-100000-10">Instrumento</label>
      <select id="instrument" name="instrument" required="">
        <option value="" id="music--schedule-form-100000-11">Selecione um instrumento</option>
        <option value="piano" id="music--schedule-form-100000-12">Piano</option>
        <option value="violao" id="music--schedule-form-100000-13">Violão</option>
        <option value="canto" id="music--schedule-form-100000-14">Canto</option>
      </select>
    </div>
    <div class="form-group" id="music--schedule-form-100000-15">
      <label for="date" id="music--schedule-form-100000-16">Data da Aula</label>
      <input type="date" id="date" name="date" required="">
    </div>
    <div class="form-group" id="music--schedule-form-100000-17">
      <label for="time" id="music--schedule-form-100000-18">Horário da Aula</label>
      <input type="time" id="time" name="time" required="">
    </div>
    <div class="form-group" id="music--schedule-form-100000-19">
      <label for="message" id="music--schedule-form-100000-20">Mensagem Adicional (Opcional)</label>
      <textarea id="message" name="message" rows="4" style="width: 100%; padding: @space-8; font-family: @font-family-primary; font-size: @font-size-16; border: 1px solid @grey-color; border-radius: 4px; background-color: @bg-primary-color; color: @text-primary-color; resize: vertical;"></textarea>
    </div>
    <button type="submit" class="submit-button" id="music--schedule-form-100000-21">Agendar Aula</button>
  </form>
`;
    }
};
organismScheduleForm = __decorate([
    customElement('music--organism-schedule-form-102023')
], organismScheduleForm);
export { organismScheduleForm };
