/// <mls shortName="organismHero" project="102023" folder="music" enhancement="_100554_enhancementLit" groupName="music" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from '_100554_icaOrganismBase';
let organismHero = class organismHero extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`music--organism-hero-102023 .hero-container{position:relative;height:400px;background-image:url('https://images.unsplash.com/photo-1681841072152-e4dd12e73cc8?crop=entropy&cs=srgb&fm=jpg&ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxtJUMzJUJBc2ljYSUyMGF1bGElMjBwcm9mZXNzb3IlMjBoZXJvfGVufDB8fHx8MTc2MzM4NDY1NXww&ixlib=rb-4.1.0&q=85');background-size:cover;background-position:center;display:flex;align-items:center;justify-content:center;text-align:center;color:var(--bg-primary-color)}music--organism-hero-102023 .hero-overlay{position:absolute;top:0;left:0;width:100%;height:100%;background-color:rgba(0,0,0,0.5)}music--organism-hero-102023 .hero-content{position:relative;z-index:1;max-width:600px;padding:var(--space-24)}music--organism-hero-102023 .hero-title{font-family:var(--font-family-primary);font-size:var(--font-size-48);font-weight:var(--font-weight-bold);margin-bottom:var(--space-16);color:var(--bg-primary-color)}music--organism-hero-102023 .hero-subtitle{font-size:var(--font-size-20);margin-bottom:var(--space-24);color:var(--bg-primary-color)}music--organism-hero-102023 .hero-button{background-color:var(--active-color);color:var(--bg-primary-color);padding:var(--space-16) var(--space-32);border:none;border-radius:4px;font-size:var(--font-size-16);font-weight:var(--font-weight-bold);cursor:pointer;transition:background-color var(--transition-normal)}music--organism-hero-102023 .hero-button:hover{background-color:var(--active-color-hover)}@media (max-width:768px){music--organism-hero-102023 .hero-container{height:300px}music--organism-hero-102023 .hero-title{font-size:var(--font-size-40)}music--organism-hero-102023 .hero-subtitle{font-size:var(--font-size-16)}}`);
    }
    render() {
        return html `<div class="hero-container" id="music--hero-100000-1">
    <div class="hero-overlay" id="music--hero-100000-2"></div>
    <div class="hero-content" id="music--hero-100000-3">
      <h1 class="hero-title" id="music--hero-100000-4">Bem-vindo às Aulas de Música!</h1>
      <p class="hero-subtitle" id="music--hero-100000-5">Descubra o prazer de tocar piano, violão ou cantar com um professor experiente.</p>
      <button class="hero-button" id="music--hero-100000-6">Agendar Aula</button>
    </div>
  </div>
`;
    }
};
organismHero = __decorate([
    customElement('music--organism-hero-102023')
], organismHero);
export { organismHero };
