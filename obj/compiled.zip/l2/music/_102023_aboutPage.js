/// <mls shortName="aboutPage" project="102023" folder="music" enhancement="_100554_enhancementLit" groupName="music" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from '_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
let PageAboutPage = class PageAboutPage extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`music--about-page-102023{display:flex;flex-direction:column;min-height:100vh}music--about-page-102023 header{position:sticky;top:0;z-index:10}music--about-page-102023 main{flex:1;padding:var(--space-32) var(--space-16)}music--about-page-102023 footer{margin-top:auto}@media (min-width:768px){music--about-page-102023 main{padding:var(--space-48) var(--space-32)}}`);
    }
    initPage() {
    }
};
PageAboutPage = __decorate([
    customElement('music--about-page-102023')
], PageAboutPage);
export { PageAboutPage };
