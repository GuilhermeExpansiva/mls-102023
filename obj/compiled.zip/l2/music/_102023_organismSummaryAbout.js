/// <mls shortName="organismSummaryAbout" project="102023" folder="music" enhancement="_100554_enhancementLit" groupName="music" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from '_100554_icaOrganismBase';
let organismSummaryAbout = class organismSummaryAbout extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`music--organism-summary-about-102023 .about-container{padding:var(--space-48) var(--space-24);background-color:var(--bg-secondary-color-lighter);display:flex;align-items:center;justify-content:space-between}music--organism-summary-about-102023 .about-text{flex:1;margin-right:var(--space-24)}music--organism-summary-about-102023 .about-title{font-family:var(--font-family-primary);font-size:var(--font-size-24);font-weight:var(--font-weight-bold);color:var(--text-primary-color);margin-bottom:var(--space-16)}music--organism-summary-about-102023 .about-description{font-size:var(--font-size-16);line-height:var(--line-height-large);color:var(--text-primary-color)}music--organism-summary-about-102023 .about-photo{flex:0 0 200px;height:200px;border-radius:50%;overflow:hidden}music--organism-summary-about-102023 .about-photo img{width:100%;height:100%;object-fit:cover}@media (max-width:768px){music--organism-summary-about-102023 .about-container{flex-direction:column;text-align:center}music--organism-summary-about-102023 .about-text{margin-right:0;margin-bottom:var(--space-24)}music--organism-summary-about-102023 .about-photo{flex:none}}`);
    }
    render() {
        return html `<div class="about-container" id="music--summary-about-100000-1">
    <div class="about-text" id="music--summary-about-100000-2">
      <h2 class="about-title" id="music--summary-about-100000-3">Sobre o Professor</h2>
      <p class="about-description" id="music--summary-about-100000-4">Sou Guilherme, professor de música com anos de experiência ensinando piano, violão e canto. Meu objetivo é tornar a música acessível e divertida para alunos de todos os níveis, desde iniciantes até avançados.</p>
    </div>
    <div class="about-photo" id="music--summary-about-100000-5">
      <img src="https://images.unsplash.com/photo-1637081877549-16c05a220892?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwcm9mZXNzb3IlMjBtJUMzJUJBc2ljYSUyMEd1aWxoZXJtZXxlbnwwfHx8fDE3NjMzODQ2NTV8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Foto do Professor Guilherme" id="music--summary-about-100000-6">
    </div>
  </div>
`;
    }
};
organismSummaryAbout = __decorate([
    customElement('music--organism-summary-about-102023')
], organismSummaryAbout);
export { organismSummaryAbout };
