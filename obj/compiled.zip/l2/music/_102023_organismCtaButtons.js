/// <mls shortName="organismCtaButtons" project="102023" folder="music" enhancement="_100554_enhancementLit" groupName="music" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from '_100554_icaOrganismBase';
let organismCtaButtons = class organismCtaButtons extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`music--organism-cta-buttons-102023 .cta-container{padding:var(--space-48) var(--space-24);background-color:var(--bg-secondary-color-lighter);text-align:center}music--organism-cta-buttons-102023 .cta-title{font-family:var(--font-family-primary);font-size:var(--font-size-24);font-weight:var(--font-weight-bold);color:var(--text-primary-color);margin-bottom:var(--space-32)}music--organism-cta-buttons-102023 .cta-buttons{display:flex;justify-content:center;gap:var(--space-24)}music--organism-cta-buttons-102023 .cta-button{background-color:var(--active-color);color:var(--bg-primary-color);padding:var(--space-16) var(--space-32);border:none;border-radius:4px;font-size:var(--font-size-16);font-weight:var(--font-weight-bold);cursor:pointer;transition:background-color var(--transition-normal)}music--organism-cta-buttons-102023 .cta-button:hover{background-color:var(--active-color-hover)}@media (max-width:768px){music--organism-cta-buttons-102023 .cta-buttons{flex-direction:column;align-items:center}music--organism-cta-buttons-102023 .cta-button{width:100%;max-width:300px}}`);
    }
    render() {
        return html `<div class="cta-container" id="music--cta-buttons-100000-1">
    <h2 class="cta-title" id="music--cta-buttons-100000-2">Entre em Contato</h2>
    <div class="cta-buttons" id="music--cta-buttons-100000-3">
      <button class="cta-button" id="music--cta-buttons-100000-4">Contato</button>
      <button class="cta-button" id="music--cta-buttons-100000-5">Agendar Aula</button>
    </div>
  </div>
`;
    }
};
organismCtaButtons = __decorate([
    customElement('music--organism-cta-buttons-102023')
], organismCtaButtons);
export { organismCtaButtons };
