/// <mls shortName="organismFooter" project="102023" folder="music" enhancement="_100554_enhancementLit" groupName="music" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from '_100554_icaOrganismBase';
let organismFooter = class organismFooter extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`music--organism-footer-102023 .footer-container{padding:var(--space-24);background-color:var(--bg-primary-color-darker);color:var(--text-primary-color-lighter);text-align:center}music--organism-footer-102023 .footer-links{display:flex;justify-content:center;gap:var(--space-24);margin-bottom:var(--space-16)}music--organism-footer-102023 .footer-link{color:var(--text-primary-color-lighter);text-decoration:none;font-size:var(--font-size-16);transition:color var(--transition-normal)}music--organism-footer-102023 .footer-link:hover{color:var(--text-secondary-color-lighter)}music--organism-footer-102023 .footer-copyright{font-size:var(--font-size-12);color:var(--text-primary-color-lighter)}@media (max-width:768px){music--organism-footer-102023 .footer-links{flex-direction:column;gap:var(--space-16)}}`);
    }
    render() {
        return html `<div class="footer-container" id="music--footer-100000-1">
    <div class="footer-links" id="music--footer-100000-2">
      <a href="#" class="footer-link" id="music--footer-100000-3">Instagram</a>
      <a href="#" class="footer-link" id="music--footer-100000-4">Facebook</a>
    </div>
    <div class="footer-copyright" id="music--footer-100000-5">© 2025 Professor de Música. Todos os direitos reservados.</div>
  </div>
`;
    }
};
organismFooter = __decorate([
    customElement('music--organism-footer-102023')
], organismFooter);
export { organismFooter };
