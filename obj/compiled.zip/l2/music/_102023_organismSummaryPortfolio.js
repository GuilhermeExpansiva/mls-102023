/// <mls shortName="organismSummaryPortfolio" project="102023" folder="music" enhancement="_100554_enhancementLit" groupName="music" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from '_100554_icaOrganismBase';
let organismSummaryPortfolio = class organismSummaryPortfolio extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`music--organism-summary-portfolio-102023 .portfolio-container{padding:var(--space-48) var(--space-24);background-color:var(--bg-primary-color);text-align:center}music--organism-summary-portfolio-102023 .portfolio-title{font-family:var(--font-family-primary);font-size:var(--font-size-24);font-weight:var(--font-weight-bold);color:var(--text-primary-color);margin-bottom:var(--space-32)}music--organism-summary-portfolio-102023 .portfolio-list{display:flex;justify-content:center;gap:var(--space-32)}music--organism-summary-portfolio-102023 .portfolio-item{text-align:center;flex:1;max-width:200px}music--organism-summary-portfolio-102023 .portfolio-icon{width:80px;height:80px;margin-bottom:var(--space-16)}music--organism-summary-portfolio-102023 .portfolio-name{font-size:var(--font-size-16);font-weight:var(--font-weight-bold);color:var(--text-primary-color)}@media (max-width:768px){music--organism-summary-portfolio-102023 .portfolio-list{flex-direction:column;align-items:center}music--organism-summary-portfolio-102023 .portfolio-item{margin-bottom:var(--space-24)}}`);
    }
    render() {
        return html `<div class="portfolio-container" id="music--summary-portfolio-100000-1">
    <h2 class="portfolio-title" id="music--summary-portfolio-100000-2">Aulas Oferecidas</h2>
    <div class="portfolio-list" id="music--summary-portfolio-100000-3">
      <div class="portfolio-item" id="music--summary-portfolio-100000-4">
        <img src="https://images.unsplash.com/photo-1713256137855-5335010af96a?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHwlQzMlQURjb25lJTIwcGlhbm8lMjBtJUMzJUJBc2ljYXxlbnwwfHx8fDE3NjMzODQ2NTV8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="Ícone de Piano" class="portfolio-icon" id="music--summary-portfolio-100000-5">
        <div class="portfolio-name" id="music--summary-portfolio-100000-6">Piano</div>
      </div>
      <div class="portfolio-item" id="music--summary-portfolio-100000-7">
        <img src="https://images.unsplash.com/photo-1603959418770-5e45cb3fc874?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHwlQzMlQURjb25lJTIwdmlvbCVDMyVBM28lMjBtJUMzJUJBc2ljYXxlbnwwfHx8fDE3NjMzODQ2NTZ8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="Ícone de Violão" class="portfolio-icon" id="music--summary-portfolio-100000-8">
        <div class="portfolio-name" id="music--summary-portfolio-100000-9">Violão</div>
      </div>
      <div class="portfolio-item" id="music--summary-portfolio-100000-10">
        <img src="https://images.unsplash.com/photo-1652626627227-acc5ce198876?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHwlQzMlQURjb25lJTIwY2FudG8lMjBtJUMzJUJBc2ljYXxlbnwwfHx8fDE3NjMzODQ2NTZ8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="Ícone de Canto" class="portfolio-icon" id="music--summary-portfolio-100000-11">
        <div class="portfolio-name" id="music--summary-portfolio-100000-12">Canto</div>
      </div>
    </div>
  </div>
`;
    }
};
organismSummaryPortfolio = __decorate([
    customElement('music--organism-summary-portfolio-102023')
], organismSummaryPortfolio);
export { organismSummaryPortfolio };
